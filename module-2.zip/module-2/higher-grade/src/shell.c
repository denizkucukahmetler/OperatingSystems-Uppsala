#include "parser.h"    //cmd_t, position_t, parse_commands()
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include <fcntl.h>     //fcntl(), F_GETFL

#define READ  0
#define WRITE 1


/**
 * For simplicitiy we use a global array to store data of each command in a
 * command pipeline .
 */
cmd_t commands[MAX_COMMANDS];

/**
 *  Debug printout of the commands array.
 */
void print_commands(int n) {
  for (int i = 0; i < n; i++) {
    printf("==> commands[%d]\n", i);
    printf("  pos = %s\n", position_to_string(commands[i].pos));
    printf("  in  = %d\n", commands[i].in);
    printf("  out = %d\n", commands[i].out);

    print_argv(commands[i].argv);
  }
}

/**
 * Returns true if file descriptor fd is open. Otherwise returns false.
 */
int is_open(int fd) {
  return fcntl(fd, F_GETFL) != -1 || errno != EBADF;
}

void fork_error() {
  perror("fork() failed)");
  exit(EXIT_FAILURE);
}

/**
 *  Fork a proccess for command with index i in the command pipeline. If needed,
 *  create a new pipe and update the in and out members for the command..
 */
void fork_cmd(int i, int pipes[][2]) {
  pid_t pid;

  switch (pid = fork()) {
    case -1:
      fork_error();
      perror("fork failed");
      exit(EXIT_FAILURE);
    case 0:
      // Child process after a successful fork().
      if (commands[i].pos == first)
      {
        //stdout, to the write end
        close(pipes[i][0]);
        dup2(pipes[i][1], STDOUT_FILENO);


        // Execute the command in the contex of the child process.
        execvp(commands[i].argv[0], commands[i].argv);

        // If execvp() succeeds, this code should never be reached.
        fprintf(stderr, "shell: command not found: %s\n", commands[i].argv[0]);
        exit(EXIT_FAILURE);     
      }
      
      else if (commands[i].pos == single)
      {
        //directly exec
        // Execute the command in the contex of the child process.
        execvp(commands[i].argv[0], commands[i].argv);

        // If execvp() succeeds, this code should never be reached.
        fprintf(stderr, "shell: command not found: %s\n", commands[i].argv[0]);
        exit(EXIT_FAILURE);   
      }

      else if (commands[i].pos == last)
      {
        //stdin to the read end
        close(pipes[i-1][1]);
        dup2(pipes[i-1][0], STDIN_FILENO);

        //close(pipes[i-1][0]);
         // Execute the command in the contex of the child process.
        execvp(commands[i].argv[0], commands[i].argv);

        // If execvp() succeeds, this code should never be reached.
        fprintf(stderr, "shell: command not found: %s\n", commands[i].argv[0]);
        exit(EXIT_FAILURE);   
      }

      else if (commands[i].pos == middle)
      {
        //stdin to the read end, stdout to the write end

        close(pipes[i-1][1]);
        dup2(pipes[i-1][0], STDIN_FILENO);

        close(pipes[i][0]);
        dup2(pipes[i][1], STDOUT_FILENO);
        
        execvp(commands[i].argv[0], commands[i].argv);
      

        // If execvp() succeeds, this code should never be reached.
        fprintf(stderr, "shell: command not found: %s\n", commands[i].argv[0]);
        exit(EXIT_FAILURE);  
        
      }
     

    default:
      // Parent process after a successful fork().
      if (i > 0)
      {
        close(pipes[i-1][0]);
        close(pipes[i-1][1]);
      }
      break;
  }
}

/**
 *  Fork one child process for each command in the command pipeline.
 */
void fork_commands(int n, int pipes[][2]) {


  for (int i = 0; i < n; i++) {
    fork_cmd(i, pipes);
  }

}

/**
 *  Reads a command line from the user and stores the string in the provided
 *  buffer.
 */
void get_line(char* buffer, size_t size) {
  getline(&buffer, &size, stdin);
  buffer[strlen(buffer)-1] = '\0';
}

/**
 * Make the parents wait for all the child processes.
 */
void wait_for_all_cmds(int n) {
  for (int i = 0; i<n ; i++)
  {
    wait(NULL);
  }
}

int main() {
  int n;               // Number of commands in a command pipeline.
  size_t size = 128;   // Max size of a command line string.
  char line[size];     // Buffer for a command line string.
  
  
  while(true) {

    printf(" >>> ");

    get_line(line, size);
    n = parse_commands(line, commands);

    int pipes[n-1][2];
    //creating n-1 pipes for children communication
    
    for(int i = 0; i<n-1; i ++ )
    {
      pipe(pipes[i]);
    }

    fork_commands(n, pipes);

    wait_for_all_cmds(n);
  }

 
  exit(EXIT_SUCCESS);
}
