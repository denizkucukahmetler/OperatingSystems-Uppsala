# Module 1 - Files

Instructions for OS/OSPP http://www.it.uu.se/education/course/homepage/os/vt20/module-1

Instructions for DSP http://www.it.uu.se/education/course/homepage/dsp/vt20/modules/module-1

