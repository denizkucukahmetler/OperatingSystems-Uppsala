/* On Mac OS (aka OS X) the ucontext.h functions are deprecated and requires the
   following define.
*/
#define _XOPEN_SOURCE 700

/* On Mac OS when compiling with gcc (clang) the -Wno-deprecated-declarations
   flag must also be used to suppress compiler warnings.
*/

#include <signal.h>   /* SIGSTKSZ (default stack size), MINDIGSTKSZ (minimal
                         stack size) */
#include <stdio.h>    /* puts(), printf(), fprintf(), perror(), setvbuf(), _IOLBF,
                         stdout, stderr */
#include <stdlib.h>   /* exit(), EXIT_SUCCESS, EXIT_FAILURE, malloc(), free() */
#include <ucontext.h> /* ucontext_t, getcontext(), makecontext(),
                         setcontext(), swapcontext() */
#include <stdbool.h>  /* true, false */

#include "sthreads.h"


/* Stack size for each context. */
#define STACK_SIZE SIGSTKSZ*100

//FOR TIMER
#define TIMEOUT    50          // ms 
#define TIMER_TYPE ITIMER_REAL // Type of timer.

/*******************************************************************************
                             Global data structures

                Add data structures to manage the threads here.
********************************************************************************/

//Maximum thread number is defined:
#define MAX_THREADS 5

//"main"
ucontext_t mainCtx;
//ready queue as a linked list of threads
struct thread ready_queue[MAX_THREADS];

//number of ready threads
int readyNum = 0;

tid_t curr = -1;

//to understand if a thread or main is executing
bool exe_thread = false;

//waiting queue
struct thread waiting_queue[MAX_THREADS];

//waiting number
int waitingNum = 0;

/*******************************************************************************
                             Auxiliary functions

                      Add internal helper functions here.
********************************************************************************/

void thread_func (void (*func)(void))
{
  --readyNum;
  ready_queue[curr].state = running;
  
  func();

  ++readyNum;
  ready_queue[curr].state = ready;
  yield();
}

extern tid_t curr_id()
{
  
  
  //find the running thread
  int run_id;

  for (run_id = 0 ; run_id< MAX_THREADS ; run_id++)
  {
    if (ready_queue[run_id].state == running)
    break;
  }
  return ready_queue[run_id].tid;
}

/*******************************************************************************
                    Implementation of the Simple Threads API
********************************************************************************/


int  init(){
  int i ;
  for (i = 0 ; i< MAX_THREADS ; i++)
  {
    ready_queue[i].state = ready;
    ready_queue[i].tid = i;
  }
  return 1;
  
  if (i!= MAX_THREADS)
  return -1;
}


tid_t spawn(void (*start)()){
  
  getcontext( &ready_queue[readyNum].ctx);

  //initializing context
  void *stack = malloc(STACK_SIZE);

  ready_queue[readyNum].ctx.uc_link= 0;
  ready_queue[readyNum].ctx.uc_stack.ss_sp = stack;
  ready_queue[readyNum].ctx.uc_stack.ss_size = STACK_SIZE;
  ready_queue[readyNum].ctx.uc_stack.ss_flags = 0;

  if (stack == 0) //Stack is not allocated
    return -1;
  
  makecontext(&ready_queue[readyNum].ctx,
   (void (*)(void)) &thread_func, 1, start);

  int temp =readyNum;
  ++readyNum;
  
  return temp;
}

void yield(){
  //if there are no ready threads, return 
  if (readyNum == 0) return;

    //if we are in thread
    if (exe_thread)
    {
      swapcontext(&ready_queue[curr].ctx, &mainCtx);
    }
    //if we are in main
    else
    {
      //go to the next thread in the queue
      curr = (curr +1 )%readyNum;
      exe_thread = true;
      swapcontext( &mainCtx, &ready_queue[curr].ctx);
      exe_thread =false;
    }
  

}

void  done(){

  //making ready->terminated
  ready_queue[curr].state = terminated;
  readyNum --;
  curr = (curr +1 )%readyNum;

  //making waiting threads-> ready
  for (int i = 0; i< MAX_THREADS ; i++)
  {
    if (ready_queue[i].state == waiting)
    {
      ready_queue[i].state = ready;
      readyNum = (readyNum +1);
      if(readyNum ==MAX_THREADS)
      readyNum = MAX_THREADS-1;
    }
  }

  //chosing a ready one in the queue and making it running

  //find a ready one
  while (ready_queue[curr].state != ready)
  {
    curr = (curr +1 )%readyNum;
  }
  //make it run
  exe_thread = true;
  swapcontext( &mainCtx, &ready_queue[curr].ctx);
  exe_thread =false;

}

tid_t join() {


  //find the running thread
  int run_id;

  for (run_id = 0 ; run_id< MAX_THREADS ; run_id++)
  {
    if (ready_queue[run_id].state == running)
    break;
  }

  //make running-> waiting
  ready_queue[run_id].state = waiting;

  //find a ready one
  int counter = 0;
  while (ready_queue[curr].state != ready)
  {
    curr = (curr +1 )%readyNum;
    counter ++;
    if (counter ==MAX_THREADS +1)
      return -1;
  }
  //make it run
  exe_thread = true;
  swapcontext( &mainCtx, &ready_queue[curr].ctx);
  exe_thread =false;

  return ready_queue[curr].tid;


}
